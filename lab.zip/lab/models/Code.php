<?php

namespace app\modules\lab\models;

use Yii;

/**
 * This is the model class for table "code".
 *
 * @property integer $id
 * @property string $val
 *
 * @property CodeReport[] $codeReports
 * @property Report[] $reports
 */
class Code extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'code';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['val'], 'required'],
           // [['val'], 'string', 'max' => 255],
 [['val'], 'integer'],
[['val'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'val' => 'Val',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCodeReports()
    {
        return $this->hasMany(CodeReport::className(), ['code_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getReports()
    {
        return $this->hasMany(Report::className(), ['id' => 'report_id'])->viaTable('code_report', ['code_id' => 'id']);
    }
}
