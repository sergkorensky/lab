<?php

namespace app\modules\lab\models;

use Yii;

/**
 * This is the model class for table "report".
 *
 * @property integer $id
 * @property string $name
 * @property string $content
 *
 * @property CodeReport[] $codeReports
 * @property Code[] $codes
 */
class Report extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'report';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name'], 'required'],
	    [['name'], 'unique'],
            [['content'], 'string'],
            [['name'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'content' => 'Content',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCodeReports()
    {
        return $this->hasMany(CodeReport::className(), ['report_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCodes()
    {
        return $this->hasMany(Code::className(), ['id' => 'code_id'])->viaTable('code_report', ['report_id' => 'id']);
    }
}
