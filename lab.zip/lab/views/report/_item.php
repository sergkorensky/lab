<?php
use yii\helpers\Html;
use yii\helpers\ArrayHelper;


/* @var $model Report 
   @var $key
   @var $index


*/
?>

<div class="reports-item">

<h3><?= Html::a(Html::encode($model->name), ['report/view','id'=>$model->id]) ?></h3>
<p>Расчетные данные:</p>
<div><pre><?= Html::encode($model->content) ?></pre></div>
<p>Коды расчета:</p>
<?php
$codes=$model->codes;
//print_r(ArrayHelper::toArray($codes));
if(count($codes) > 0){

foreach($codes as $code) echo '<p>'.$code->val.'</p>';

}else{echo 'Нет кодов';}
?>
</div>
