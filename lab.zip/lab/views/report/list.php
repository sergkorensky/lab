<?php

use yii\helpers\Html;
use yii\widgets\ListView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel app\modules\lab\models\ReportSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Расчеты лаборатории';
$this->params['breadcrumbs'][] = $this->title;
$sign=['<','=','>'];
//echo \Yii::$app->db->driverName;
?>
<div class="report-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php 
//echo $this->render('_search', ['model' => $searchModel]); 
?>

    <p>
        <?= Html::a('Create Report', ['create'], ['class' => 'btn btn-success']) ?>
    </p>


<p> 
       <?= Html::beginForm([''], 'post') ?> 
<?=  'Поиск расчетов, в которых есть коды '.Html::dropDownList('sign',$filtersign,$sign,['prompt'=>'Все','class'=>'signchoice'] ).
Html::textInput('value',$filterval)  ?>


<?= Html::submitButton('Найти', ['class' => 'submit']) ?>


<?= Html::endForm() ?>
    </p>



<?php Pjax::begin(); ?>    <?= ListView::widget([
        'dataProvider' => $dataProvider,
        'itemOptions' => ['class' => 'item'],
        'itemView' => '_item',
    ]) ?>
<?php Pjax::end(); ?></div>
<?php
$css='.signchoice {display:inline;}
';
$this->registerCss($css);
?>

