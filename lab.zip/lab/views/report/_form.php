<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\modules\lab\models\Report */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="report-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'content')->textarea(['rows' => 6]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary', 'id'=>'send']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>


<?php
$script = '$(document).ready(function(){

$("#send").on("click",function(event){

var content=$("#report-content").val();

//alert(content);

var re=/{([\+\-]?[\d]+)}/g;

var result, code, html;

//alert("First re.lastIndex="+re.lastIndex);

while(result=re.exec(content)) {

//alert(result[0]+", "+parseInt(result[1]));

code=parseInt(result[1]);

html="<input type=hidden name=code[] value="+code+">";

$("form").append(html);

}

//alert("Finnaly re.lastIndex="+re.lastIndex);

//event.preventDefault();

});

});';

$this->registerJs($script, \yii\web\View::POS_END);
?>
