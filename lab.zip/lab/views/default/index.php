<?php
use yii\helpers\Html;

?>

<div class="lab-default-index">
    <h1>Модуль расчеты лаборатории</h1>
  <h3>  <?= Html::a('Расчеты', ['/lab/report/list']) ?> </h3>
</div>
