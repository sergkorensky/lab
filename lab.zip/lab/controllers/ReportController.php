<?php

namespace app\modules\lab\controllers;

use Yii;
use app\modules\lab\models\Report;
use app\modules\lab\models\Code;
use app\modules\lab\models\ReportSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\validators\NumberValidator;
use yii\db\Query;
use yii\data\ActiveDataProvider;

/**
 * ReportController implements the CRUD actions for Report model.
 */
class ReportController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Report models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new ReportSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

/**
     * Lists all Report models.
     * @return mixed
     */
    public function actionList()
    {
        $query= new Query;

$sql="select * from report";

$filtersign=null;
$filterval=null;

if(isset($_POST['sign']) and isset($_POST['value'])){

$sign=$_POST['sign']; $value=$_POST['value'];
$validator= new NumberValidator;
$validator->integerOnly=true;
$znaki=['<','=','>'];
if($validator->validate($value) and $validator->validate($sign) and isset($znaki[$sign])){

$db=Yii::$app->db;

if($db->driverName == 'pgsql') {
$sql ="select a.* from report a inner join code_report b on a.id=b.report_id ";
$sql.=" inner join code c on b.code_id=c.id  where cast (c.val as integer ) {$znaki[$sign]} $value group by a.id";//pgsql
}
if($db->driverName == 'mysql') {
$sql ="select a.* from report a inner join code_report b on a.id=b.report_id ";
$sql.=" inner join code c on b.code_id=c.id  where convert(c.val, signed) {$znaki[$sign]} $value group by a.id";//mysql
}
$filtersign=$sign;
$filterval=$value;
}

}



	$query=Report::findBySql($sql);

        $dataProvider = new ActiveDataProvider([
	    'query' => $query,

]);

        return $this->render('list', [
   
            'dataProvider' => $dataProvider, 'filtersign'=>$filtersign, 'filterval'=>$filterval,
        ]);
    }

    /**
     * Displays a single Report model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new Report model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */

    public function actionCreate()
    {
        $model = new Report();

$validator= new NumberValidator;
$validator->integerOnly=true;


        if ($model->load(Yii::$app->request->post()) && $model->save()) {//надо получить и сохранить коды

if( isset($_POST['code']) )
{

$codes=$_POST['code']; 

foreach($codes as $code){

if($validator->validate($code)){



$oldcode=Code::find()->where(['val'=>$code])->one();

if($oldcode === null){

$newcode= new Code;

$newcode->val=$code;

if($newcode->save()) $model->link('codes',$newcode);

} else   if (!in_array($oldcode, $model->codes))  $model->link('codes',$oldcode);



}


}

}
//коды сохранены
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**  Можно отключить.
     * Updates an existing Report model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }
*/
    /**
     * Deletes an existing Report model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Report model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Report the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Report::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
