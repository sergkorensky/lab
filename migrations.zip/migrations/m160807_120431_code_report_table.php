<?php

use yii\db\Migration;

class m160807_120431_code_report_table extends Migration
{
    public function up()
    {

$tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            $tableOptions = 'CHARACTER SET utf8 ENGINE=InnoDB';
        }

$this->createTable('{{%code_report}}', [
          'code_id' => $this->Integer()->notNull(),
  	  'report_id' => $this->Integer()->notNull(),
	
                        
        ], $tableOptions);


$this->addPrimaryKey ('pk_code_report', '{{%code_report}}', ['code_id', 'report_id'] );

$this->addForeignKey('fk_code_report_code','{{%code_report}}',
 'code_id', '{{%code}}', 'id', 'CASCADE', 'NO ACTION');

$this->addForeignKey('fk_code_report_report','{{%code_report}}',
 'report_id', '{{%report}}', 'id', 'CASCADE', 'NO ACTION');

    }

    public function down()
    {
        //echo "m160807_120431_code_report_table cannot be reverted.\n";
$this->dropTable('{{%code_report}}');
        //return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
