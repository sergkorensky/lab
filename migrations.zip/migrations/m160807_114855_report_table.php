<?php

use yii\db\Migration;

class m160807_114855_report_table extends Migration
{
    public function up()
    {

$tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            $tableOptions = 'CHARACTER SET utf8 ENGINE=InnoDB';
        }

$this->createTable('{{%report}}', [
            'id' => $this->primaryKey(),
            'name' => $this->string()->notNull(),
		'content' => $this->text(),
                        
        ], $tableOptions);


    }

    public function down()
    {
        //echo "m160807_114855_report_table cannot be reverted.\n";
	 $this->dropTable('{{%report}}');
        //return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
