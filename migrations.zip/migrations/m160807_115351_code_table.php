<?php

use yii\db\Migration;

class m160807_115351_code_table extends Migration
{
    public function up()
    {

$tableOptions = null;
        if ($this->db->driverName === 'mysql') {
            $tableOptions = 'CHARACTER SET utf8 ENGINE=InnoDB';
        }

$this->createTable('{{%code}}', [
            'id' => $this->primaryKey(),
            'val' => $this->string()->notNull(),
	
                        
        ], $tableOptions);

    }

    public function down()
    {
        //echo "m160807_115351_code_table cannot be reverted.\n";
	$this->dropTable('{{%code}}');
        //return false;
    }

    /*
    // Use safeUp/safeDown to run migration code within a transaction
    public function safeUp()
    {
    }

    public function safeDown()
    {
    }
    */
}
